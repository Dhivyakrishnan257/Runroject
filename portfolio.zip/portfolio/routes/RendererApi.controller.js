var mongodb = require('mongodb');
      var mongoClient = mongodb.MongoClient;
      var url = 'mongodb://localhost:27017/Portfolio-Management';
      var chickletDef = require("../public/json/ChickletDefinition.json");
      var port_def =  {};
      var filter_profile= {};

      module.exports={
      initialMerger: function(resolve, reject, prortfolioId) {
      mongoClient.connect(url, function(err, db) {
          if (err) {

          } else {

            if(prortfolioId == undefined)
            {
                portfolioDefName="projectDefinition";
                o_id = require('mongodb').ObjectID('57e8ca700ab9b49174edea08');
              }
              else{
                portfolioDefName="projectDefinition";

                o_id = require('mongodb').ObjectID(prortfolioId);
              }
              db.collection(portfolioDefName).find({
                  "_id": o_id
              }).toArray(function(err, portfolioDef) {
                  for (var val in portfolioDef) {
                      for (var values in portfolioDef[val].sections) {
                          for (var chicklet in portfolioDef[val].sections[values].chicklets) {
                              for (var dir_name in chickletDef.chicklet) {
                                  if (portfolioDef[val].sections[values].chicklets[chicklet]['chicklet-directive-name'] === dir_name) {
                                      for (var field in chickletDef.chicklet[dir_name].fields) {
                                          var obj = chickletDef.chicklet[dir_name].fields;
                                          for (var display in chickletDef.chicklet[dir_name].fields[field]) {
                                              if (display != "displayName") {
                                                  delete chickletDef.chicklet[dir_name].fields[field][display];
                                              }
                                          }
                                          portfolioDef[val].sections[values].chicklets[chicklet]['chicklet_data'] = obj;
                                          delete obj;
                                      }
                                  }
                              }
                          }
                      }

                  }

                  resolve(portfolioDef);
              });
          }
      });
      },

      profileData : function (resolve, reject, profileId) {

      mongoClient.connect(url, function(err, db) {
          if (err) {
                        } else {
              var o_id = require('mongodb').ObjectID(profileId);

              var cursor = db.collection('user_profile').find({
                  "_id": o_id
              }).toArray(function(err, profile) {

                  resolve(profile);
              });

          }
      });

    },

      filterAPI: function (resolve, reject, portfolio) {
      var filterArray = [];
      for (var section in portfolio[0]['sections']) {
          for (var chicklet in portfolio[0]['sections'][section]['chicklets']) {
              for (var filter in portfolio[0]['sections'][section]['chicklets'][chicklet]) {
                  if (filter == 'filter' && portfolio[0]['sections'][section]['chicklets'][chicklet][filter].length>0 ) {
                      var obj = {};
                      obj['chickletCount']=portfolio[0]['sections'][section]['chicklets'][chicklet]['filter'][0]['chickletCount'];
                      obj['section_id']=portfolio[0]['sections'][section]['section_id'];
                      obj['section_directive_name'] = portfolio[0]['sections'][section]['section_directive_name'];
                      obj['chicklet-directive-name'] = portfolio[0]['sections'][section]['chicklets'][chicklet]['chicklet-directive-name'];
                      obj['filter'] = portfolio[0]['sections'][section]['chicklets'][chicklet]['filter'];
                      filterArray.push(obj);
                  }
              }
          }
      }
      resolve(filterArray);

      },
      filterProfile:function (resolve, reject,filterArray, profile) {
        console.log(JSON.stringify(filterArray));
       var relation = {
         "equals": "==",
         contains: function(profileValue,textValue) {
           var expression = '(?!<[\w\d])'+textValue+'(?![\w\d])';
           var regex = new RegExp(expression);
           var matches = regex.exec(profileValue);
           if(matches == null) return false;
           else {
             return true;
           }
         },
         "greaterThan": ">",
         "lessThan": "<",
         "and": "&&",
         "or": "||",
         "undefined": ''
      };
      for (var section in profile[0].profiles.sections) {

          for (var filterSection in filterArray) {

              if (profile[0].profiles.sections[section]['section_id'] == filterArray[filterSection]['section_id']){
                  var array = [];
                  for (var chicklet in profile[0].profiles.sections[section].chicklets) {
                      if (profile[0].profiles.sections[section].chicklets[chicklet]['chicklet-directive-name'] == filterArray[filterSection]['chicklet-directive-name']) {
                        if(filterArray[filterSection]['filter'][0]['selectedField']!=undefined){
                          var relationFormulation = "";
                          for (var index in filter = filterArray[filterSection]['filter']) {
                            if(filterArray[filterSection]['filter'][index].selectedRelation !== "contains"){
                              relationFormulation += relation[filterArray[filterSection]['filter'][index].relation] + JSON.stringify(profile[0].profiles.sections[section].chicklets[chicklet].chicklet_data[filter[index].selectedField.fieldname].value) + relation[filterArray[filterSection]['filter'][index].selectedRelation] + JSON.stringify(filter[index].textValue);
                              console.log(relationFormulation);

                            }
                            else {
                              var contains = relation[filterArray[filterSection]['filter'][index].selectedRelation](profile[0].profiles.sections[section].chicklets[chicklet].chicklet_data[filter[index].selectedField.fieldname].value,filter[index].textValue)
                              relationFormulation += relation[filterArray[filterSection]['filter'][index].relation] +  contains;
                            }
                          }
                          if (!eval(relationFormulation)) {
                              array.push(chicklet);
                          }
                        }
                      }
                  }
                  var removeIndex = 0;
                  for (var i = 0; i < array.length; i++) {
                      profile[0].profiles.sections[section].chicklets.splice(array[i] - removeIndex, 1);
                      removeIndex++;
                  }

                  if(filterArray[filterSection]['chickletCount']!=undefined && profile[0].profiles.sections[section].chicklets.length>=filterArray[filterSection]['chickletCount']){
                    profile[0].profiles.sections[section].chicklets.length=filterArray[filterSection]['chickletCount'];
                  };
              }
          }
      }


        resolve(profile[0]);
      }

      };

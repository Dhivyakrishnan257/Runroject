var express = require('express');
var router = express.Router();
var mongoUtil = require('../db/mongoUtil');
var ObjectId = require('mongodb').ObjectID;
router.get('/team/:userId?', function(req, res) {
  var db = mongoUtil.getDb();
  db.collection('users').find({
    "_id": ObjectId(req.params.userId)
  }).toArray(function(err, docs) {
    if (err) {
      handleError(res, err.message, "Failed to get contacts.");
    } else {
      res.status(200).json(docs[0].teams);
    }
  });
});

router.post('/team/:userId?', function(req, res) {
  var object = req.body;
  object["_id"] = new ObjectId();
  var db = mongoUtil.getDb();
  db.collection('users').update({
    "_id": ObjectId(req.params.userId)
  }, {
    $push: {
      "teams": object
    }
  }, function(err, doc) {
    if (err) {
      handleError(res, err.message, "Failed to create new contact.");
    } else {
      res.status(201).json(doc);
    }
  });
});

router.patch('/team/:userId?', function(req, res) {
  var object = req.body;
  var db = mongoUtil.getDb();
  console.log(object);
  db.collection('users').update({
    "_id": ObjectId(req.params.userId)
  }, {
    $set: {
      'teams': object
    }
  }, function(err, result) {
    if (err) {
      handleError(res, err.message, "Failed to delete contact");
    } else {
      res.status(204).end();
    }
  });
});


router.patch('/team/:teamId/:userId?', function(req, res) {
  var object = req.body;
  var db = mongoUtil.getDb();
  db.collection('users').update({
    "_id": ObjectId(req.params.userId),
    "teams._id": req.params.teamId
  }, {
    $set: {
      'teams.$.name': object.name,
      'teams.$.description': object.description
    }
  }, function(err, result) {
    if (err) {
      handleError(res, err.message, "Failed to delete contact");
    } else {
      res.status(204).end();
    }
  });
});

router.delete('/team/:userId/:id?', function(req, res) {
  var db = mongoUtil.getDb();
  db.collection('users').update({
    "_id": ObjectId(req.params.userId)
  }, {
    $pull: {
      "teams": {
        "_id": ObjectId(req.params.id)
      }
    }
  }, function(err, result) {
    if (err) {
      handleError(res, err.message, "Failed to delete saved search");
    } else {
      res.status(204).end();
    }
  });
});



module.exports = router;

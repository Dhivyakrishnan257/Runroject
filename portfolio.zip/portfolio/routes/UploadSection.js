var express = require('express');
var router = express.Router();
router.get("/UploadSection",function(req,res,next)
{
  var fs = require('fs');
  fs.readFile('professionalExpTwo.tmpl.html', 'utf8', function(err, data) {
      if (err) throw err;
      var parser = new DOMParser();
      var doc = parser.parseFromString(data, 'text/xml');
      var elements = doc.getElementsByTagName('ng-transclude');
      var heading = doc.getElementsByTagName('div');
      for (var i = 0; i < heading.length; i++) {
          if (heading[i].hasAttribute('ng-cloak')) {
              heading[i].setAttribute('class', 'transparent try parallax1 container-fluid section_border')
          }
          if (heading[i].hasAttribute('headingDiv')) {
              var haedingChild = ('<md-button class="md-fab md-mini close_button" ng-click="removeSection()($event,sectionDndName,sectionName)" aria-label="close section"><md-icon md-svg-src="img/icons/cake.svg"></md-icon></md-button>');
              var headingCode = parser.parseFromString(haedingChild, 'text/xml');
              heading[i].appendChild(headingCode);
          }
      }

      for (var i = 0; i < elements.length; i++) {
          var slotName = elements[i].getAttribute('ng-transclude-slot');
          var dndChild = ('<div class="col-sm-12 medium_height no_padding" ><div class="button_visible" layout="column" layout-align="center center" layout-fill> <md-button ng-click="removeButton()($event,sectionName)" class="md-fab md-primary" aria-label="add" > <md-icon class="material-icons"></md-icon> </md-button> </div> <div class="dnd_disappear" layout-fill> <md-button class="md-fab md-mini close_button" ng-click="removeChicklet()($event,sectionName)" aria-label="close chicklet"> <md-icon md-svg-src="img/icons/cake.svg"></md-icon> </md-button> <ul class="no_padding" dnd-list="" layout="column" layout-align="center center" dnd-drop="dropChicklet()(event, index, item, external,sectionName)"  slot="' + slotName + '" section={{sectionName}} layout-fill> </ul></div></div>');
          var dndCode = parser.parseFromString(dndChild, 'text/xml');
          elements[i].parentNode.appendChild(dndCode);
      }
      var elements = doc.getElementsByTagName('ng-transclude');
      for (var i = 0; i < elements.length; i++) {
          elements[i].parentNode.removeChild(elements[i]);
      }
      parseString(doc, function(err, result) {
          var builder = new xml2js.Builder();
          var xml = builder.buildObject(result);

          fs.writeFile("sample.html", xml, "utf8", function(error) {
              if (error)
                  throw error;
          });
          res.send('done!!');
      });
  });
});
module.exports = router;

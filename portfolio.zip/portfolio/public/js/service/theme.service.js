angular.module('portfolio')
    .service('theming', ["$http", function ($http) {
      this.getData = function(portfolioId) {
        if(portfolioId === "")
        {
          return $http.get('/getThemeData');
        }
        return $http.get('/getThemeData/'+portfolioId);
        }
    }]);

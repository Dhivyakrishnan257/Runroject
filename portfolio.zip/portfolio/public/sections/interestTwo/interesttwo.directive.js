angular.module('portfolio')
  .directive('interestSectionTwo', function() {
    return {
      templateUrl: 'sections/interestTwo/interesttwo.tmpl.html',
        scope: {
          sectionName: '@',
          displayName:'@'
      },
      transclude: {
        'placeholder-f': '?placeholderF',
        'placeholder-g': '?placeholderG',
        'placeholder-h': '?placeholderH',
        'placeholder-i': '?placeholderI',
        'placeholder-j': '?placeholderJ'
      }
    }
  });

angular.module('ProSearch')
  .controller('teamCtrl', ['$http', 'team', '$scope', '$mdDialog','$window', function($http, team, $scope, $mdDialog,$window) {
    //List all the teams created by the user.
    $scope.teams = [];
    team.getTeams().success(function mySucces(teams) {
      $scope.teams = teams;
    });

    //Listing Profiles based on a team.
    $scope.listProfiles = function(teamName, teamId) {
      $scope.teamName = teamName;
      $scope.teamId = teamId;
      $scope.profiles = [];
      team.getProfiles(teamName).success(function(profiles) {
        $scope.profiles = profiles[0].teamMembers;
        // console.log(profiles[0].teamMembers);

      });
    };

    //Adds a new Team.
    $scope.addTeam = function(event) {
      //Dialog box
      $mdDialog.show({
        templateUrl: 'views/addTeamDialog.html',
        targetEvent: event,
        controller: data,
        scope: $scope
      })
    };

    function data($scope, $mdDialog) {
      $scope.hide = function() {
        $mdDialog.hide();
      };
      $scope.cancel = function() {
        $mdDialog.cancel();
      };
      $scope.saveData = function() {
        var newTeamDetails = {};
        newTeamDetails["name"] = $scope.Name;
        newTeamDetails["description"] = $scope.Description;
        $scope.teams.push(newTeamDetails);
        console.log($scope.teams);
        team.addTeam(newTeamDetails);
            // alert('New team added successfully');

          //console.log($scope.teams);
        $mdDialog.hide();
      };
    }

    //For removing the team
    $scope.removeTeam = function(event, teamName) {
      //Confirm Dialog box
      var confirm = $mdDialog.confirm()
        .title('Would you like to remove Team?')
        .targetEvent(event)
        .ok('Confirm')
        .cancel('Nope');
      $mdDialog.show(confirm).then(function() {
          //Calling service to get the team details to push the whole object into archive list
          team.getProfiles(teamName).success(function(profiles) {
            //Pushing the archiveTeam object into list.json
            team.archiveTeam(profiles);
          });
          for (var i = 0; i < $scope.teams.length; i++) {
            if ($scope.teams[i].name == teamName) {
              var index = i;
            }
          }
          $scope.teams.splice(index, 1);
          //$scope.teams.splice(teamId-1, 1);
          //calling service to remove the team based on teamid
          team.removeTeam(teamName).success(function(response) {
            alert('Team has been Removed.');
          });
        },
        function() {
          alert('Team has not been Removed.');
        });
    };

    //Rename Team.
    $scope.renameTeam = function(event, teamName) {
      // console.log(teamName);
      team.getProfiles(teamName).success(function(profiles) {
        $scope.content = profiles;
        // console.log(profiles);
        //Dialog box
        $mdDialog.show({
          templateUrl: 'views/editTeamDialog.html',
          targetEvent: event,
          scope: $scope,
          local: {
            key: $scope.content
          },
          controller: update
        })
      });
      //To update the team name and team description
      function update($scope, $mdDialog) {
        // console.log($scope.content[0].id);
        $scope.hide = function() {
          $mdDialog.hide();
        };
        $scope.cancel = function() {
          $mdDialog.cancel();
        };
        $scope.updateTeam = function() {
          var UpdatedTeamDetails = {};
          console.log($scope.Name);
          UpdatedTeamDetails["name"] = $scope.Name;
          UpdatedTeamDetails["description"] = $scope.Description;
          for (var i = 0; i < $scope.teams.length; i++) {
            console.log(teamName);
            console.log($scope.teams[i].name);
            if ($scope.teams[i].name == teamName) {
              var index = i;
            }
          }
          console.log(index);
          $scope.teams[index].name = $scope.Name;
          $scope.teams[index].description = $scope.Description;
          team.editTeam(UpdatedTeamDetails, teamName);
            // alert('Team updated successfully');

          $mdDialog.hide();
        };
      }
    };

    //This will list all the teams with archive teams
    $scope.archiveTeams = [];
    $scope.viewAll = function() {
      //Getting all the teams removed by the user.
      team.getArchiveTeams().success(function mySucces(archiveTeams) {
        $scope.archiveTeams = archiveTeams;
      });
    };

    //Listing archive Profiles based on a teamid.
    $scope.listArchiveProfiles = function(teamName, teamId) {
      $scope.teamName = teamName;
      $scope.teamId = teamId;
      $scope.profiles = [];
      team.getArchiveProfiles(teamId).success(function(profiles) {
        $scope.profiles = profiles.Team_Members;
      });
      console.log($scope.profiles);
    };

    //Undo the team based on teamId
    $scope.undo = function(teamId) {
      team.getArchiveProfiles(teamId).success(function(profiles) {
        team.addTeam(profiles);
        $scope.teams.push(profiles);
        for (var i = 0; i < $scope.archiveTeams.length; i++) {
          if ($scope.archiveTeams[i].id == teamId) {
            var index = i;
          }
        }
        $scope.archiveTeams.splice(index, 1);
        team.removeArchiveTeam(teamId);
          // alert('Undo successfull');

      });
    };

    $scope.logout = function(event) {
      $window.localStorage.removeItem("authToken");
      $window.location.href="/login.html";
    };
  }]);

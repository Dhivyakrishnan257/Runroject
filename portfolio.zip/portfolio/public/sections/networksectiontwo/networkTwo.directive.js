angular.module('portfolio')
  .directive('networkTwo', function() {
    return {
      templateUrl: 'sections/networksectiontwo/networkTwo.tmpl.html',
      scope: {
        sectionName: '@',
        displayName:'@'
      },
      transclude: {
        'placeholder-alpha': '?placeholderAlpha',
        'placeholder-beta': '?placeholderBeta'
      },
      controller: function($rootScope,$scope) {
    
      }
    }
  });

var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://localhost",neo4j.auth.basic('neo4j','1234'));
var session = driver.session();

module.exports = session;

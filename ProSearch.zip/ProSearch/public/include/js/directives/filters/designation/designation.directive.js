angular.module('ProSearch')
  .directive('designation', function() {
    return {
      templateUrl: 'include/js/directives/filters/designation/designation.tmpl.html',
      scope: {
        type: '<',
        values: '<'
      },
      controller: "designationCtrl"
    }
  })

var MongoClient = require('mongodb').MongoClient;

var _db;
var _db2;
var ObjectID = MongoClient.ObjectID;
module.exports = {
  connectToServer: function(callback) {  
    MongoClient.connect("mongodb://localhost/Portfolio-Management", function(err, db) {
      if (err) {
        console.log("Unable to connect to PortfolioDb");
      }
      else {
        _db = db;   
        console.log("PortfolioDb is Up and Running");
        return callback(err);  
      }   
    }); 
    MongoClient.connect("mongodb://localhost/ontology-keywords", function(err, db1) {   
      if (err) {
        console.log("Unable to connect to KeywordsDb");
      }
      else {
        _db2 = db1;   
        console.log("KeywordsDb is Up and Running");
        return callback(err);  
      }
    }); 
  },
  getDb: function() {  
    return _db; 
  },
  getKeywordsDb: function() {
    return _db2;
  }
};

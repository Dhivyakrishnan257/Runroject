angular.module('ProSearch')
  .controller('locationCtrl', ['$scope', 'autoComplete', '$http', '$routeParams', function($scope, autoComplete, $http, $routeParams) {
    "use strict";
    $scope.searchLocation = "";

    $scope.isDisabled = false;
    $scope.noCache = false;

    $scope.searchLocation = function(str1) {
      return autoComplete.getLocation(str1).then(function(response) {
        if (typeof response.data === 'object') {
          return response.data;
        } else {
          // invalid response
          return $q.reject(response.data);
        }
      });
    }
  }]);

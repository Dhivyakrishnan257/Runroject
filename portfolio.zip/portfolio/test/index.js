// var request = require('supertest');
// var app = require('../app.js');
// var mongodb=require('mongodb');
// var mongoClient=mongodb.MongoClient;
// var url='localhost/Portfolio-Management';
// describe('Testing Merge Controller', function() {
//   it('Should check if all the sections are present', function(done) {
//
//     var p1= new Promise(function(resolve,reject){
//       request(app)
//       .get('/RendererApi/57f2465893cc2a6626c171fa/')
//       .end(function(err,res){
//         console.log(res);
//         resolve(res.body[0].profiles.sections.length);
//       });
//     });
//     var p2=new Promise(function(resolve,reject){
//       request(app)
//       .get('/testingPortfolioStructure/57e8ca700ab9b49174edea08')
//       .end(function(err,res){
//         console.log(res.body);
//         resolve(res.body);
//       });
//     });
//     done();
//   });
// });

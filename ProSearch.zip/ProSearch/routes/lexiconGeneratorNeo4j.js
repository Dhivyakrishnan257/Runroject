var nlp = require('nlp_compromise');
var async = require('async');
var session = require('../db/neo4jUtil.js');
var skills = require('../db/dictionary/skills.json');
var location = require('../db/dictionary/location.json');
var qualification = require('../db/dictionary/qualification.json');
var roles = require('../db/dictionary/roles.json');
var companies = require('../db/dictionary/companies.json');

//parses the individual terms to the lexicon format. Ex. {"angularjs":"skills"}
var lexiconParse = function(term, tag) {
  var lexicon = {};
  var normalizedTerm = nlp.term(term).normalize();
  lexicon["type"] = tag;
  lexicon["term"] = normalizedTerm;
  return lexicon;
};

//array of dictionary
var dictionaries = [{
  terms: location,
  type: "location"
}, {
  terms: skills,
  type: "skills"
}, {
  terms: qualification,
  type: "qualification"
}, {
  terms: roles,
  type: "roles"
}, {
  terms: companies,
  type: "organization"
}];

//Generates a lexicon parser function for all the dictionaries.
var lexiconMapper = dictionaries.map(function(dictionary) {
  return function(callback) {
    var lexiconDictionary = dictionary.terms.map(function(location) {
      return lexiconParse(location, dictionary.type);
    });
    callback(null, lexiconDictionary);
  };
});

//Converts all the terms into their equivalent lexicons in parallel.
async.parallel(lexiconMapper, function(err, results) {
  results.forEach(function(dictionary) {
    dictionary.forEach(function(lexicon) {
      var query = "MERGE (term:" + lexicon.type + " {name: {termParam}}) return term";
      session.run(query, {
        termParam: lexicon.term
      }).then(function(record) {
        console.log(record);
      }).catch(function(err) {
        console.log(err);
      });
    });
  });
});

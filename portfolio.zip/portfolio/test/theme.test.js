var supertest = require("supertest");
var should = require("should");
var app = require("../app");

describe("Theme.js",function(){

  // #1 should return home page
  it("expect 200",function(done){

  // calling home page api
  supertest(app)
    .get("/themes")
    .expect("Content-type",/json/)
    .end(function(err,res){
      res.status.should.equal(200);
        done();
    });

  });
  it("Themelist testing", function(done)
{
  supertest(app)
    .get("/themeList")
    .expect("Content-type",/json/)
    .end(function(err,res){
      res.status.should.equal(200);
      done();
})
});
it("getDefaultTheme", function(done)
{
supertest(app)
  .get("/getDefaultTheme")
  .expect("Content-type",/json/)
  .end(function(err,res){
    res.status.should.equal(200);
    done();
})
});
});

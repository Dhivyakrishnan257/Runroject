angular.module('portfolio')
 .directive('followedPeople',function() {
 return {
     templateUrl: 'chicklets/followed/followed.tmpl.html',
     scope: {
          sectionName:'@',
          chickletPath: '=chickletPath',
          theming : '='
     },
     controller: function($scope,$rootScope,$mdDialog) {
       $scope.editEnabled = $rootScope.editEnabled;
       $scope.chickletData = $scope.chickletPath['chicklet_data'];
       $scope.chickletName = $scope.chickletPath['chickletid'];
       $scope.chicklets=$scope.chickletPath;
       $scope.followedModal=function(chickletData,sectionName,chickletName,chicklets){
       $mdDialog.show({
             templateUrl:'/views/followed_modal.html',
             locals: { chickletData: chickletData,
                       sectionName:sectionName,
                       chickletName:chickletName,
                     chicklets:chicklets,
                   theme : $scope.theming["cardTheme"]},
             controller:"DialogController"
       });
       };
     }
 }
});

angular.module('ProSearch')
  .service('searchResult', ["$http", function($http) {

    //Service to add the save search
    this.addSaveSearch = function(searchTerm, userId) {
      return $http.post('/api/savedSearch/' + userId, searchTerm);
    };
  }]);

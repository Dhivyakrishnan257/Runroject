var express = require('express');
var router = express.Router();
var mongodb = require('mongodb');
var mongoClient = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/Portfolio-Management';

router.get('/CreatePortfolio/sections',function(req,res,next)
{
  mongoClient.connect(url, function(err, db) {
      if (err) {

      } else {
          var cursor = db.collection('repository');
          var sections = cursor.find().toArray(function(err, docs) {
              var obj;
              var sections = "";
              if (err) throw err;
              obj = {
                  "sections": docs
              };
              res.json(obj["sections"]);
          });
      }
  });
});
module.exports = router;

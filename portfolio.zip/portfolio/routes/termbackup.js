var nlp = require('nlp_compromise');
var highland = require('highland');
var getTags = require('./getTags');
var events = require('events');
var _ = require('underscore');
var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://localhost",neo4j.auth.basic('neo4j','1234'));
var session = driver.session();
var userData;
var async = require('async');

module.exports = {
 buildIndexes : function(profile) {
   var terms = "";
   var operations = [];
   var profileId = profile._id;
        profile.profiles.sections.forEach(function(section) {
        	section.chicklets.forEach(function(chicklet) {
        		var chickletData = chicklet.chicklet_data;
        		for(prop in chickletData) {
        			if(chickletData[prop].value !== undefined) {
                terms += chickletData[prop].value+" ";
        			}
        		}
        	});
        });

  terms = terms.replace(/,/g," ");
  terms = nlp.sentence(terms).normal();
  terms+=" ";

    var removeUser = session.run('MATCH (user:Profile {id:{userId}}) DETACH DELETE user',{userId:profile._id})

    var lexiconStream = highland();
    removeUser.then(function() {
      session.run('MATCH (terms) WHERE labels(terms) in ["organization","skills","location","roles","qualification"] return terms')
      .subscribe({
        onNext: function(lexicon) {
        lexicon._fields[0].labels.forEach(function(label) {
          var term = {};
          term[label] = lexicon._fields[0].properties.name;
          term[lexicon._fields[0].properties.name] = label;
          lexiconStream.write(term);
        })
      },
      onCompleted: function() {

        lexiconStream.end();
      },
      onError: function(err) {

      }
    })
  	var extendObj = highland.extend();

    lexiconStream
  		.map(function(lexicon) {

  			var lexicon = _.omit(lexicon,'_id','location','skills','organization','roles','qualification');

        var tag = getTags(terms,lexicon);

        if(tag !== undefined) {

  				return tag
  			}
  		}).map(function(tag) {
  			if(tag !== undefined) {
          var term = _.keys(tag)[0];

        	var relations = require("./"+tag[term])(term,profile);
          relations.type = tag[term];

          return relations;
  			}
  		}).map(function(d) {
  			if(d !== undefined && d.relations.length > 0) {
          d.profileId = profile._id;
          profile.profiles.sections.forEach(function(section){
            section.chicklets.forEach(function(chicklet){
              if(chicklet.chickletid == 'PROFILE_DATA')
              d.username=chicklet.chicklet_data.name.value
            });
          });


  				return d;
  			};
  		}).each(function(d) {
        if(d !== undefined && d.type !== "skills") {

          					d.relations.forEach(function(relation) {
                      var mergeOperation = function(callback) {

                        var query = "MERGE (user:Profile {id:{userId}}) WITH user MATCH(term:"+d.type+" {term:{termParam}}) MERGE (user)-[relation:`"+relation.relationName+"`]->(term) ON CREATE SET relation={relationshipParam},user.name={nameParam}";
                        session.run(query,{nameParam: d.username,userId:d.profileId,termParam:d.term,relationshipParam:relation}).then(function(data) {

                          callback(null,data);
                        }).catch(function(err) {

                          callback(err);
                        });
                      };
                      operations.push(mergeOperation);
          					});
        }
  			else if(d !== undefined && d.type == "skills") {

            d.relations.forEach(function(relation) {

              var mergeOperation = function(callback) {
                var sameAsRelationships = "MERGE (user:Profile {id:{userId},name:{username}}) WITH user OPTIONAL MATCH (term:skills {name:{termToBeSearched}}) WITH term OPTIONAL MATCH (term)-[:sameAs]-(sameAsTerms:skills) WITH term,sameAsTerms,collect(term)+collect(sameAsTerms) as terms WITH term,terms OPTIONAL MATCH (user:Profile {id:{userId}})-[]-(connectedTerm) WHERE connectedTerm in terms return term,connectedTerm,user,terms,ID(term),ID(connectedTerm),ID(user)";
                session.run(sameAsRelationships,{termToBeSearched:d.term,userId:d.profileId,username:d.username}).then(function(data) {
                  var promise,user,term,connectedTerm,connectedTerm,relatedTerms,connectedTermID,termID,userID;
                  for(record of data.records) {
                    term = record._fields[0];
                    relatedTerms = record._fields[3];
                    termID = (record._fields[4])?(record._fields[4].low):(null);
                    user = record._fields[1];
                    userID = (record._fields[6])?(record._fields[6].low):(null);
                    connectedTerm = record._fields[2];
                    connectedTermID = (record._fields[5])?(record._fields[5].low):(null);
                    if(connectedTerm&&user) {
                      break;
                    };
                  };
                  if(connectedTerm) {
                    var query = "MATCH (user:Profile {id:{userId}}) MATCH (connectedTerm:skills) WHERE ID(connectedTerm)="+connectedTermID+" WITH user,connectedTerm MERGE (user)-[relation:"+relation.relationName+"]->(connectedTerm) ON MATCH SET relation.intensity=relation.intensity+"+relation.intensity+" ON CREATE SET relation={relationshipParam} return user,connectedTerm";
                    promise = new Promise(function(resolve,reject) {
                      session.run(query,{userId:d.profileId,relationshipParam:relation,connectedTermID:connectedTermID,userID:userID}).then(function(data){

                        resolve(relatedTerms);
                      },function(err) {

                        reject(err);
                      });
                    })
                  } else {
                    var query = "MATCH (user:Profile {id:{userId}}) MATCH (term:skills) where ID(term)="+termID+" WITH user,term CREATE (user)-[relation:"+relation.relationName+"]->(term) SET relation={relationshipParam} return user,term";
                    promise = new Promise(function(resolve,reject) {
                      session.run(query,{userId:d.profileId,relationshipParam:relation,termID:termID}).then(function(data) {

                        resolve(relatedTerms);
                      },function(err) {

                        reject(err);
                      });
                    });
                  }
                  promise.then(function(relatedTerms) {
                    var idsOfRelatedTerms = '';
                    relatedTerms.forEach(function(term) {
                      idsOfRelatedTerms+=term.identity.low+',';

                    });
                    idsOfRelatedTerms = idsOfRelatedTerms.substring(0,idsOfRelatedTerms.length-1);
                    return session.run("MATCH (terms:skills)-[:partWhole]->(higherOrderTerms:skills) where ID(terms) in ["+idsOfRelatedTerms+"] WITH collect(higherOrderTerms) as terms OPTIONAL MATCH(term) WHERE term in terms OPTIONAL MATCH (term)-[:sameAs]-(x)-[]-(user) WHERE term in terms AND ID(user)="+userID+" return term,x UNION MATCH (terms:skills)-[:partWhole]->(higherOrderTerms:skills) where ID(terms) in ["+idsOfRelatedTerms+"] WITH collect(higherOrderTerms) as terms OPTIONAL MATCH(term) WHERE term in terms OPTIONAL MATCH (term)-[]-(user) WHERE term in terms AND ID(user)="+userID+" return term,term as x")
                  }).then(function(data) {
                    var index = 0;
                    for(var record of data.records){
                      var higherOrderTerm = record._fields[0];
                      var connectedTerm = record._fields[1];
                      if(connectedTerm) {
                        var connectedTermID = connectedTerm.identity.low;
                        var query = "MATCH (user:Profile {id:{userId}}) MATCH (connectedTerm:skills) WHERE ID(connectedTerm)="+connectedTermID+" WITH user,connectedTerm MERGE (user)-[relation:"+relation.relationName+"]->(connectedTerm) ON MATCH SET relation.intensity=relation.intensity+"+relation.intensity+" ON CREATE SET relation={relationshipParam} return user,connectedTerm";
                        session.run(query,{userId:d.profileId,relationshipParam:relation,connectedTermID:connectedTermID,userID:userID}).then(function(data){

                          callback(null,data);
                        },function(err) {

                        });
                        break;
                      } else if(index == data.records.length -1 && higherOrderTerm) {
                        var termID = higherOrderTerm.identity.low;
                        var query = "MATCH (user:Profile {id:{userId}}) MATCH (term:skills) where ID(term)="+termID+" WITH user,term CREATE (user)-[relation:"+relation.relationName+"]->(term) SET relation={relationshipParam} return user,term";
                        session.run(query,{userId:d.profileId,relationshipParam:relation}).then(function(data) {

                          callback(null,data);
                        },function(err) {

                          callback(err,null);
                        });
                      } else if(index == data.records.length -1) {
                        callback(null,1);
                      }
                      index++;
                    };
                  },function(err) {

                  }).catch(function(err) {

                  });
                }).catch(function(err) {

                });
                };
                operations.push(mergeOperation);
              });
  					};
  		}).done(function() {

        async.series(operations,function(err,results) {

        });
      })
  });
}
};

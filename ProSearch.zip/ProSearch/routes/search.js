var session = require('../db/neo4jUtil.js');
var _ = require('underscore');
var skillExpansion = require('./skillExpansion.js');

var getProfiles = function(termCollection,skillCollection) {
  var query;
  if(skillCollection) {
    if(termCollection !== "[]") {
      console.log("termCollection");
      console.log(termCollection);
      query = "MATCH (x:skills)-[r]-(user:Profile) where x.name in "+skillCollection+" WITH user,r OPTIONAL MATCH (x)-[s]-(term) WHERE term.name in "+termCollection+" OR term.term in " +termCollection+ " WITH user,SUM(toInt(r.intensity))+SUM(toInt(s.intensity)) as intensity return user,intensity order by intensity DESC"
    } else {
      console.log("term")
      query = "MATCH (x:skills)-[r]-(user:Profile) where x.name in "+skillCollection+" WITH user,SUM(toInt(r.intensity)) as intensity return user,intensity order by intensity DESC";
    }
  } else {
    query = "MATCH (user:Profile)-[r]-(term) where term.name in "+termCollection+" OR term.term in "+termCollection+" WITH user,SUM(toInt(r.intensity)) as index,collect(DISTINCT term) as terms where length(terms) = length("+termCollection+") return DISTINCT user,index order by index DESC";
  }
  return session.run(query);
};

var search = function(terms) {
  var skillCollection = "";
  var termCollection = "";
  terms.forEach(function(term,index,arr) {
    if(term[_.keys(term)] == "skills") {
      skillCollection += '"'+_.keys(term)+'",';
    } else {
      termCollection+= '"'+_.keys(term)+'",';
    }
  });
  termCollection = "[" + termCollection.replace(/,\s*$/, "") + "]"
  if(skillCollection != "") {
    skillCollection = "[" + skillCollection.replace(/,\s*$/, "") + "]";
    return skillExpansion.expand(session,skillCollection).then(function(expandedSkills) {
      return getProfiles(termCollection,expandedSkills);
    });
  } else {
    return getProfiles(termCollection);
  };
};

module.exports = search;

angular.module('app')
.directive('networkTwoDnd',function($compile){
    return {
      restrict:'CEA',
      templateUrl:function(elem,attr){
        if(attr.edit=="false"){
          return 'sections/networksectiontwo/networktwoDnd.tmpl.html';
        }else if (attr.edit=="true") {

                    return '';
        }
      },
      link:function($scope,elem,attr){
        if(attr.edit=="true"){
          elem.html('');
          var html=$compile(attr.template)($scope);
          elem.append(html);
        }
      }
      ,
      scope: {
        template:'@',
        edit:'=edit',
        sectionName: '@',
        displayName:'@',
        removeButton:'&',
        dropChicklet:'&',
        removeSection:'&',
        removeChicklet:'&',
        showAdvanced:'&',
        sectionDndName:'@'
      },
      transclude: {
        'placeholder-alpha': '?placeholderAlpha',
        'placeholder-beta': '?placeholderBeta',
      },
    }
  });

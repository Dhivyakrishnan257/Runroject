angular.module('ProSearch')
  .controller('skillsCtrl', ['$q', '$rootScope','$scope','$http', 'autoComplete', function($q,$rootScope, $http,$scope, autoComplete) {
    "use strict";
    $scope.searchSkill = "";
    $scope.isDisabled = false;
    $scope.noCache = false;
    $scope.selectedItemChange = function(item) {
      var selectedSkill = $scope.selectedLocation;
      $rootScope.searchResult = [];
      $rootScope.searchTerm = $rootScope.searchTerm + " " + item;
      $http.get("/api/profiles/" + $rootScope.searchTerm).then(function(response) {
        $rootScope.selectedPersons = $rootScope.searchResult.length;
      });


    }
    $scope.searchSkill = function(searchText) {
      return autoComplete.getSkill(searchText).then(function(response) {
        var skills = [];
        for (var i = 0; i < response.data.records.length; i++) {
          skills.push(response.data.records[i]._fields[0]);
        }
        return skills;
      });
    }
  }]);

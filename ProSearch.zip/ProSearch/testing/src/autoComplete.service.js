angular.module('ProSearch')
  .service('autoComplete', ['$http', '$q', function($http, $q) {
    this.getSkill = function(skill) {
      return $http.get('/api/autoCompleteSkill/?skill=' + skill);
    }
    this.getLocation = function(city) {
      return $http.get("/api/autoCompleteLocation/?location=" + city);
    }
  }]);

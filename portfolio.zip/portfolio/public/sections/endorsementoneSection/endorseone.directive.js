 angular.module('portfolio')
 .directive('endorsementsoneSection',function() {
   return {
     templateUrl: 'sections/endorsementoneSection/endorseone.tmpl.html',
       scope: {
         sectionName: '@',
         displayName:'@'
     },
     transclude: {
         'placeholder-sone': '?placeholderSone'
     }
   }
});

var util = require("util");
var _ = require("lodash");
var fs = require("fs");
var mongodb = require('mongodb');
var express = require("express");
var router = express.Router();
var mergedProfile = [];

var portfolioDef = require("../../json/portfolioDefinition123.json");
var profileDef = require("../../json/user_profile.json");

var userProfile;
router.get('/',function(req,res){

  for(var values in portfolioDef.sections)
  {
    for(var values1 in profileDef)
    {
      for(var values2 in profileDef[values1])
      {
        for(var sections in profileDef[values1][values2].sections)
        {
          for(var chicklet in portfolioDef.sections[values].chicklet)
          {
            for(var chicklets in profileDef[values1][values2].sections[sections].chicklets)
            {
              for(var chickletData in portfolioDef.sections[values].chicklet[chicklet])
              {
                if(profileDef[values1][values2].sections[sections].chicklets[chicklets]["chicklet-directive-name"] == portfolioDef.sections[values].chicklet[chicklet][chickletData])
                    {
                      for(var pro_chicklet in profileDef[values1][values2].sections[sections].chicklets[chicklets])
                        {
                          if(pro_chicklet == "chicklet_data")
                            {
                              for(var apollo in profileDef[values1][values2].sections[sections].chicklets[chicklets][pro_chicklet])
                              {
                                if(profileDef[values1][values2].sections[sections].chicklets[chicklets][pro_chicklet][apollo]['value']==undefined){
                                  profileDef[values1][values2].sections[sections].chicklets[chicklets][pro_chicklet][apollo]['value']="";
                                }
                                for(var master in profileDef[values1][values2].sections[sections].chicklets[chicklets][pro_chicklet][apollo])
                                {
                                    portfolioDef.sections[values].chicklet[chicklet][pro_chicklet][apollo]["value"] = profileDef[values1][values2].sections[sections].chicklets[chicklets][pro_chicklet][apollo][master];
                                }
                              }
                            }
                        }
                    }
                  }
                }
              }
            }
          }
        }
      }
    res.json(portfolioDef);
});
module.exports = router;

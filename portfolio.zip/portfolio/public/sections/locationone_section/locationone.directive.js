angular.module('portfolio')
  .directive('locationoneSection', function() {
    return {
      templateUrl: 'sections/locationone_section/locationone.section.html',
      scope: {
        sectionName: '@',
        displayName:'@'
      },
      transclude: {
        'placeholder-one': '?placeholderOne',
         'placeholder-two': '?placeholderTwo'
         },
      controller: function($rootScope,$scope) {
      }
    }
  });

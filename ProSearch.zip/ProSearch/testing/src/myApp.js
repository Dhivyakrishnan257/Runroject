//jwt code starts here
function authInterceptor($window) {
  return {
    // automatically attach Authorization header
    request: function(config) {
      //$window.localStorage.removeItem("authToken");
      var token = $window.localStorage["authToken"];
      if((config.url.indexOf('localhost:8082') === 0 || (config.url.indexOf('/api') === 0)) && token) {
        config.headers["x-access-token"]=token;
      }
      else if(!token)
      {
        $window.location.href="/login.html";
        // return;
      }
      return config;
    },

    // If a token was sent back, save it
    response: function(res) {
      //console.log("in interceptor "+ res);
        if(res.config.url.indexOf('localhost:8082') === 0 && res.data.token) {
          //auth.saveToken(res.data.token);
          $window.localStorage["authToken"]=res.data.token;
      }
      return res;
    }
  }
}
//jwt ends here.
angular.module("ProSearch", ['ngRoute', 'ngMaterial', 'ngMessages'])
.factory('authInterceptor',authInterceptor)
.config(function($httpProvider) {
  $httpProvider.interceptors.push('authInterceptor');
})
  .config(["$routeProvider", function($routeProvider) {
    $routeProvider
    //loads home view
      .when("/home", {
        templateUrl: "views/home.html",
        controller: "mainCtrl"
      })
      //loads smart search view
      .when("/smartSearch", {
        templateUrl: "views/smartSearch.html",
        controller: "mainCtrl"
      })
      //loads mylist view
      .when("/myList", {
        templateUrl: "views/myList.html",
        controller: "teamCtrl"
      })
      //loads search results view
      .when("/searchResults/:searchTerm", {
        templateUrl: "views/searchResults.html",
        controller: "search"
      })
      .when("/bot",{
        templateUrl: "views/bot.html",
        controller: "bot"
      })
      //by default it loads home view
      .otherwise({
        redirectTo: "/home"
      });
  }]);

angular.module('ProSearch')
  .service('team', ["$http", function($http) {

    //Service to get all the team names
    this.getTeams = function(userId) {
      return $http.get('/api/team/' + userId);
    };

    //Service to get the profiles based on team id
    this.getProfiles = function(userId) {
      return $http.get('/api/team/' + userId);
    };

    //Service to add the team
    this.addTeam = function(newTeamDetails, userId) {
      return $http.post('/api/team/' + userId, newTeamDetails);
    };

    //Service to remove the team
    this.removeTeam = function(userId, teamId) {
      return $http.delete("/api/team/" + userId + "/" + teamId);
    };

    //Service to add the team in archive list
    this.archiveTeam = function(userId, archiveTeamDetails) {
      return $http.post('/api/archiveTeam/' + userId, archiveTeamDetails);
    };

    //Service to get the teams in archicedTeams
    this.getArchiveTeams = function(userId) {
      return $http.get('/api/archiveTeam/' + userId);
    };

    //Service to update the team name
    this.editTeam = function(UpdatedTeamDetails, teamId, userId) {

      $http.patch('/api/team/' + teamId + '/' + userId, UpdatedTeamDetails);
    };

    //Service to get the archive profiles based on team id

    //Service to remove archive team
    this.removeArchiveTeam = function(userId, teamId) {
      return $http.delete("/api/archiveTeam/" + userId + "/" + teamId);
    };
  }]);

angular.module('portfolio')
  .directive('educationSectionOne', function() {
    return {
      templateUrl: 'sections/educationSectionOne/education_section/education.section.html',
      scope: {
        sectionName: '@',
        displayName:'@'
      },
      transclude: {
          'placeholder-a': '?placeholderA',
          'placeholder-b': '?placeholderB',
          'placeholder-c': '?placeholderC',
          'placeholder-d': '?placeholderD'
        },
      controller: function($rootScope,$scope) {
      }
    }
  });

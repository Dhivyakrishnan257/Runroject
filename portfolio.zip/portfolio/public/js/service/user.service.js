angular.module('portfolio')
  .service('profile', function($http) {
    this.getData = function(profileId,portfolioId) {
      if(portfolioId === "")
      {
          return $http.get("/RendererApi/"+profileId);
      }
      return $http.get("/RendererApi/"+profileId+"/"+portfolioId);
    }
    this.getSkillByTypedString=function(str){
     return $http.get('/skills/'+str);
    }

    this.postSkills=function(skills,userId){
      var user={
        "skills":skills,
        "id":userId
      }
      return $http.post('/updateSkills',user);
    }
  })

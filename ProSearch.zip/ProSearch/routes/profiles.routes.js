var express = require('express');
var router = express.Router();
var mongoUtil = require('../db/mongoUtil');
var getEssentialTerms = require("./termExtraction.js");
var removeStopWords = require("./stopwords.js");
var search = require("./search.js");
var ObjectId = require("mongodb").ObjectID;
var session = require('../db/neo4jUtil.js');

router.get('/profiles/:searchTerm?', function(req, res) {
  var db = mongoUtil.getDb();
  var searchTerm = req.params.searchTerm;
  var userProfiles = [];
  var promises = [];
  var queryunknownwords = [];
  getEssentialTerms(searchTerm).then(function(extractedTerm) {
   removeStopWords(searchTerm,extractedTerm).then(function(unknownwords){
     queryunknownwords = unknownwords;
    search(extractedTerm).then(function(profiles) {
      // console.log("no.of records");
      // console.log(  profiles.records.length);
      profiles.records.forEach(function(record) {
        // console.log(record._fields[0].properties);
        var promise = new Promise(function(resolve, reject) {
          db.collection('user_profile').find({
            "_id": ObjectId(record._fields[0].properties.id)
          }).toArray(function(err, docs) {
            if (err) {
              // console.log("error in mongo");
              handleError(res, err.message, "Failed to get contacts.");
              reject();
            }
            else {
              // console.log("profile");
              // console.log(docs[0]);
              session.run('MATCH (user:Profile {id:"'+docs[0]._id+'"})-[]-(skill:skills) return DISTINCT skill').then(function(skills) {
                var skillsOnProfile = [];
                skills.records.forEach(function(skill) {
                  skillsOnProfile.push(skill._fields[0].properties.name);
                });
            // resolve({profile:docs[0],intensity:record._fields[1].low});
                resolve({profile:docs[0],intensity:record._fields[1].low,skills:skillsOnProfile});
              });
            }
          });
        });
        promises.push(promise);
      });

      Promise.all(promises).then(function(profiles) {
        var results={};
        results.userProfiles = profiles;
        results.unknownwords = queryunknownwords;
        res.json(results);
      });

    },function(err) {console.log(err);});

},function(err) {console.log(err);});
}),function(err) {console.log(err);};
 });

router.get('/filters', function(req, res) {
  var db = mongoUtil.getDb();
  db.collection('filters').find({}).toArray(function(err, docs) {
    if (err) {
      handleError(res, err.message, "Failed to get contacts.");
    } else {
      res.status(200).json(docs);
    }
  });
});


router.get('/autoCompleteSkill/:skill?', function(req, res) {
  var term = req.params.skill.toLowerCase();
  var query = "MATCH (skill:skills) WHERE skill.name STARTS WITH \"" + term + "\" return skill.name"
  session.run(query).then(function(records) {
    res.send(records);
  }).catch(function(err) {
    console.log(err);
  });
});

router.get('/autoCompleteDesignation/:designation?', function(req, res) {
  var term = req.params.designation.toLowerCase();
  var query = "MATCH (role:roles) WHERE role.name STARTS WITH \"" + term + "\" return role.name"
  session.run(query).then(function(records) {
    res.send(records);
  }).catch(function(err) {
    console.log(err);
  });
});
router.get('/autoCompleteLocation/:location?', function(req, res) {
  var term = req.params.location.toLowerCase();
  var query = "MATCH (location:location) WHERE location.name STARTS WITH \"" + term + "\" return location.name"
  session.run(query).then(function(records) {
    res.send(records);
  }).catch(function(err) {
    console.log(err);
  });
});

module.exports = router;

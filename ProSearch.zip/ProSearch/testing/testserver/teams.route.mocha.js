var supertest = require("supertest");
var should = require("should");

var server = supertest.agent("http://localhost:8080");

describe("Testing the team",function(){
  it("should return teams api",function(done){
    server
    .get("/api/team")
    .expect("Content-type",/json/)
    .expect(200)
    .end(function(err,res){
      res.res.statusCode.should.equal(200);
      done();
    });
  });

  it("should return teams based on name",function(done){
    var name="Team-1";
    server
    .get("/api/team/"+name)
    .expect("Content-type",/json/)
    .expect(200)
    .end(function(err,res){
      res.res.statusCode.should.equal(200);
      done();
    });
  });

  it("should post new teams",function(done){
   server
   .post('/api/team')
   .send({name:"new",description: "This is a team of Programmers"})
   .expect("Content-type",/json/)
   .expect(201)
   .end(function(err,res){
     res.res.statusCode.should.equal(201);
     done();
   });
 });

 it("should rename a team",function(done){
  var name="Team-1";
  server
  .patch('/api/team/'+name)
  .send({name:"new",description: "This is a team of Programmers"})
  .expect("Content-type",/json/)
  .expect(204)
  .end(function(err,res){
    res.res.statusCode.should.equal(204);
    done();
  });
});


it("should delete a team",function(done){
  var name="Team-1";
 server
 .delete('/api/team/'+name)
 .send({name:"new",description: "This is a team of Programmers"})
 .expect("Content-type",/json/)
 .expect(204)
 .end(function(err,res){
  //  console.log(res.req.socket._httpMessage.ClientRequest);
   res.res.statusCode.should.equal(204);
   done();
 });
});

});

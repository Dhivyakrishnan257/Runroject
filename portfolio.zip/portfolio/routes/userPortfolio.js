var express = require('express');
var router = express.Router();
var mongodb = require('mongodb');
var mongoClient = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/Portfolio-Management';

router.get('/userPortfolio/:userId',function(req,res,next)
{
mongoClient.connect(url, function(err, db) {
  if (err) {
    } else {
          var cursor = db.collection('user_portfolio');
          var sections = cursor.find({"userId":req.param("userId")}).toArray(function(err, docs) {
              var obj;
              var sections = "";
              if (err) throw err;
              res.json(docs);
          });
      }
  });
});
module.exports = router;

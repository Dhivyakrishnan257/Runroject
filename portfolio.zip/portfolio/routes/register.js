var express = require('express');
var router = express.Router();
var request = require('request');
var mongoUtil = require( '../db/mongoUtil' );
var jwt = require('jsonwebtoken');
var obj1;

router.get('/:email?',function(req,res){
  var db = mongoUtil.getConnection();
  var email=req.param('email');
  db.collection('authenticate').find({'email':email}).toArray(function(err,user){
  if(err) throw err;
    else {
      res.status(200).json(user[0]);
    }
  });
});

router.post('/', function(req, res) {
  var object = req.body;
  var db = mongoUtil.getConnection();
  var user = {};
  db.collection('signupProfile').find().toArray(function(err, doc){
    user.profiles = doc[0].profiles;
    user.profiles.sections.forEach(function(section,index){
      section.chicklets.forEach(function(chicklet,index){
        if(chicklet.chickletid === 'PROFILE_DATA'){
          chicklet.chicklet_data.name.value=req.body.username;

      }
        if(chicklet.chickletid === 'CONTACT_INFORMATION') {
          chicklet.chicklet_data.email.value=req.body.email;
        }
      });
    });
    db.collection("user_profile").insertOne(user, function(err,user) {
    var authUser = {
        email: req.body.email,
        password: req.body.password,
        username: req.body.username,
        userProfileId: user.ops[0]._id
      }
      db.collection("authenticate").insertOne(authUser,function(err,authUser) {
      })
      res.status(200).json(authUser);
    });
});
});
module.exports = router;

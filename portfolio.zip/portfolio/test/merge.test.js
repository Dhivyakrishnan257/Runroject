// var request = require('supertest');
// var chai = require('chai');
// var _ = require('lodash');
// var app = require('../app.js');
// var mongodb=require('mongodb');
// var mongoClient=mongodb.MongoClient;
// var url='localhost/Portfolio-Management';
//
// describe('Testing Merge Controller', function() {
//   it('Should check if all the sections are present', function(done) {
//     var p1= new Promise(function(resolve,reject){
//       request(app)
//       .get('/RendererApi/57d8f80f81e9f4535ccb3b21/57f73e83dd5de2087a98f8ad/')
//       .end(function(err,res){
//         resolve(res.body[0]);
//       });
//     });
//
//     var p2=new Promise(function(resolve,reject){
//       request(app)
//       .get('/testingPortfolioStructure/57f73e83dd5de2087a98f8ad')
//       .end(function(err,res){
//         // console.log(res.body);
//         resolve(res.body);
//       });
//     });
//     function compareSection(length,rendererObj,mongoObj){
//       var mongoArr=[];
//       var rendererArr=[];
//       for(var i=0;i<length;i++){
//         if(chai.expect(rendererObj[i]).to.contain.all.keys(['section_id','section_directive_name','heading','placeholders','chicklets']) && chai.expect(mongoObj[i]).to.contain.all.keys(['section_id','section_directive_name','heading','placeholders','chicklets'])){
//           rendererArr.push({'sectionName':rendererObj[i].section_directive_name,'chicklets':rendererObj[i].chicklets});
//           mongoArr.push({'sectionName':mongoObj[i].section_directive_name,'chicklets':mongoObj[i].chicklets});
//         }
//       }
//       var sorted_rendererArr=_.sortBy(rendererArr,'sectionName');
//       var sorted_mongoArr=_.sortBy(mongoArr,'sectionName');
//       return {'renderer':sorted_rendererArr,'mongo':sorted_mongoArr};
//     }
//     function compareChicklet(length, CompareArray) {
//         var mongoArr = [];
//         var rendererArr = [];
//         var rendererCount = 0;
//         var mongoCount = 0;
//         for (var i = 0; i < length; i++) {
//             if (CompareArray.renderer[i].chicklets.length > 0) {
//                 for (var j = 0; j < CompareArray.renderer[i].chicklets.length; j++) {
//                     if (chai.expect(CompareArray.renderer[i].chicklets[j]).to.contain.all.keys(['chickletid', 'chicklet-directive-name', 'placeholderId', 'chicklet_data'])) {
//                         rendererCount++;
//                     }
//                 }
//             }
//
//             for (var j = 0; j < CompareArray.mongo[i].chicklets.length; j++) {
//                 if (chai.expect(CompareArray.mongo[i].chicklets[j]).to.contain.all.keys(['chickletid', 'chicklet-directive-name', 'placeholderId'])) {
//                     mongoCount++;
//                 }
//             }
//         }
//         console.log(rendererCount);
//         console.log(mongoCount);
//         return true;
//     }
//     Promise.all([p1,p2]).then(function(data){
//       console.log(data[0].profiles.sections.length);
//       console.log(data[1][0].sections.length);
//       chai.expect(data[0].profiles.sections.length).to.equal(data[1][0].sections.length);
//       var length=data[0].profiles.sections.length;
//       var CompareArray=compareSection(length,data[0].profiles.sections,data[1][0].sections);
//       var Compare_chicklet_Array=compareChicklet(length,CompareArray);
//       done();
//     });
//   });
// });

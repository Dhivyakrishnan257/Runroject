angular.module('ProSearch')
  .controller('experienceCtrl', ['$scope', '$rootScope', 'autoComplete', '$http', '$routeParams', function($scope, $rootScope, autoComplete, $http, $routeParams) {
    //For Filters
    var filteredArray = [];
    $scope.searchExperience = function(experience) {
      if (experience == ">5") {
        var compareValue = experience[1];
        for (var i = 0; i < $rootScope.searchResult.length; i++) {
          var text = $rootScope.searchResult[i].sections[8].chicklets[0].chickletData.timeSpentOnIt.value[0];

          if (parseInt(text) >= parseInt(compareValue)) {
            filteredArray.push($rootScope.searchResult[i]);
          }
        }
      } else {
        var l = experience[0];
        var u = experience[2];
        for (var i = 0; i < $rootScope.searchResult.length; i++) {
          var text = $rootScope.searchResult[i].sections[8].chicklets[0].chickletData.timeSpentOnIt.value[0];

          if (parseInt(text) >= parseInt(l) && parseInt(text) <= parseInt(u)) {
            filteredArray.push($rootScope.searchResult[i]);
          }
        }
      }
      $rootScope.searchResult = [];
      $rootScope.searchResult = filteredArray;
      $rootScope.selectedPersons = $rootScope.searchResult.length;
    }
  }]);

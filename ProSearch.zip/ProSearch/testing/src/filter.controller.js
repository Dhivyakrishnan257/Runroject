angular.module('ProSearch')
  .controller('filterCtrl', function($scope, filter) {
    //reading filters
    filter.readFilters().success(function(filters) {
        $scope.filters=filters[0].filterList;
    });

  });

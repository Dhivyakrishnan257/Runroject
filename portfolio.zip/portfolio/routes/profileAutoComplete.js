var express = require('express');
var router = express.Router();
var mongodb = require('mongodb');
var mongoClient = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/Portfolio-Management';

router.get('/profileAutoComplete/:string',function(req,res,next)
{
    mongoClient.connect(url, function(err, db) {
        if (err) {

        } else {

                    var cursor = db.collection('authenticate');
                    cursor.find({username:new RegExp(req.param('string'), 'i')},{username:1,userProfileId:1}).toArray(function(err, response) {
                      if(err){

                      }
                      res.json(response);
                    
                      });
                    }
            });

    });
module.exports = router;

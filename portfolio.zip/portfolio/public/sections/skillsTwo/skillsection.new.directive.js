angular.module('portfolio')
  .directive('skillSectionNew', function() {
    return {
      templateUrl: 'sections/skillsTwo/skillsection.new.tmpl.html',
      scope: {
        sectionName: '@',
        displayName:'@'
      },
      transclude: {
        'placeholder-skillb': '?placeholderSkillb',
          'placeholder-skillc': '?placeholderSkillc'
      },
      controller: function($rootScope,$scope) {
      
      }
    }
  });

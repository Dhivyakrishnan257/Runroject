var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://10.219.85.98",neo4j.auth.basic('neo4j','password'));

var session = driver.session();

session.run('Create (alice:person {name:"Blahh"}) return alice.name')
	.subscribe({
		onNext: function(data) {

		},
		onCompleted: function(data) {

		},
		onError: function(data) {

		}
	});

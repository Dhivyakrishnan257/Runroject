angular.module('ProSearch')
  .directive('locations', function() {
    return {
      templateUrl: 'include/js/directives/filters/locations/locations.tmpl.html',
      scope: {
        type: '<'
      },
      //defining controller for autocomplete
      controller: "locationCtrl"
    }
  })
